const data = [
    {
        question: 'Вопрос 1: Что на самом деле представляет из себя легендарный зеленый код из «Матрицы»?',
        answers: [
            {
                id: '1',
                value: ' Рецепт суши',
                correct: true,
            },
            {
                id: '2',
                value: 'Рецепт Пад Тая',
                correct: false,
            },

            {
                id: '3',
                value: 'Рецепт жаркого',
                correct: false,
            },
            
            {
                id: '4',
                value: 'Рецепт пельменей',
                correct: false,
            },
        ]
    },
    {
        question: 'Вопрос 2: Где снимали трилогию «Властелин колец»?',
        answers: [
            {
                id: '5',
                value: 'В Ирландии',
                correct: false,
            },
            {
                id: '6',
                value: 'В Испании',
                correct: false,
            },
            {
                id: '7',
                value: 'В Новой Зеландии',
                correct: true,
            },
            {
                id: '8',
                value: 'В Австралии',
                correct:  false,
            },
        ]
    },

    {
        question: 'Вопрос 3: В какую страну отправился Форрест Гамп в составе сборной США по настольному теннису?',
        answers: [
            {
                id: '9',
                value: 'Во Вьетнам',
                correct: false,
            },
            {
                id: '10',
                value: 'В Китай',
                correct: true,
            },

            {
                id: '11',
                value: 'В Швецию',
                correct: false,
            },
            {
                id: '12',
                value: 'Во Францию',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 4: Кому принадлежал тот самый кот из «Крестного отца»?',
        answers: [
            {
                id: '13',
                value: 'Фрэнсису Копполе',
                correct: false,
            },
            {
                id: '14',
                value: 'Дайан Китон',
                correct: false,
            },

            {
                id: '15',
                value: 'Аль Пачино',
                correct: false,
            },
            {
                id: '16',
                value: 'Никому — животное было бездомным',
                correct: true,
            },
            
        ]
    },
    {
        question: 'Вопрос 5: Какой фильм стал самым кассовым в 2014 году?',
        answers: [
            {
                id: '17',
                value: '«Голодные игры: Сойка-пересмешница. Часть I»',
                correct: false,
            },
            {
                id: '18',
                value: '«ЛЕГО Фильм»',
                correct: false,
            },

            {
                id: '19',
                value: '«Первый мститель: Другая война»',
                correct: false,
            },
            {
                id: '20',
                value: '«Стражи Галактики»',
                correct: true,
            },
            
        ]
    },
    {
        question: 'Правда или ложь? Шон Коннери носил парик в каждом фильме о Джеймсе Бонде',
        answers: [
            {
                id: '21',
                value: 'Правда',
                correct: true,
            },
            {
                id: '22',
                value: 'Ложь',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 7: Какой предмет есть в каждой сцене «Бойцовского клуба»?',
        answers: [
            {
                id: '23',
                value: 'Банка Coca-Cola',
                correct: false,
            },
            {
                id: '24',
                value: 'Стаканчик Starbucks',
                correct: true,
            },

            {
                id: '25',
                value: 'Пончик Dunkin’',
                correct: false,
            },
            {
                id: '26',
                value: 'Бутылка Pepsi',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 8: Если бы вы захотели посмотреть фильмы Marvel в хронологическом порядке, какой фильм вы бы включили в первую очередь?',
        answers: [
            {
                id: '27',
                value: '«Железный человек»',
                correct: false,
            },
            {
                id: '28',
                value: '«Доктор Стрэндж»',
                correct: false,
            },

            {
                id: '29',
                value: ' «Первый мститель»',
                correct: true,
            },
            {
                id: '30',
                value: '«Капитан Марвел»',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 9: Какой актер не играл Джокера?',
        answers: [
            {
                id: '31',
                value: 'Джек Николсон',
                correct: false,
            },
            {
                id: '32',
                value: 'Шон Пенн',
                correct: true,
            },

            {
                id: '33',
                value: 'Джаред Лето',
                correct: false,
            },
            {
                id: '34',
                value: 'Марк Хэмилл',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 10: Какие фильмы сняты по одному сценарию?',
        answers: [
            {
                id: '35',
                value: '«Звездные войны» и «Близкие контакты третьей степени»',
                correct: false,
            },
            {
                id: '36',
                value: '«Балбесы» и «Индиана Джонс»',
                correct: false,
            },

            {
                id: '37',
                value: '«Парк Юрского периода» и «Земля до начала времен»',
                correct: false,
            },
            {
                id: '38',
                value: '«Инопланетянин» и «Полтергейст»',
                correct: true,
            },
            
        ]
    },
    {
        question: 'Вопрос 11: Сколько Оскаров выиграла Холли Берри?',
        answers: [
            {
                id: '39',
                value: '0',
                correct: false,
            },
            {
                id: '40',
                value: '4',
                correct: false,
            },

            {
                id: '41',
                value: '1',
                correct: true,
            },
            {
                id: '42',
                value: '2',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 12: Из какого фильма цитата: «Что в коробке?»',
        answers: [
            {
                id: '43',
                value: '«Бешеные псы»',
                correct: false,
            },
            {
                id: '44',
                value: 'Святые из Бундока»',
                correct: false,
            },

            {
                id: '45',
                value: '«Скорость»',
                correct: false,
            },
            {
                id: '46',
                value: '«Семь»',
                correct: true,
            },
            
        ]
    },
    {
        question: 'Вопрос 13: Кого из профессиональных спортсменов хотели взять на главную роль в «Терминаторе»?',
        answers: [
            {
                id: '47',
                value: 'Дэна Марино',
                correct: false,
            },
            {
                id: '48',
                value: ' Майка Тайсона',
                correct: false,
            },

            {
                id: '49',
                value: ' О. Дж. Симпсона',
                correct: true,
            },
            {
                id: '50',
                value: 'Уэйна Гретцки',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Правда или ложь? «Сияние» — первый роман Стивена Кинга, который был экранизирован',
        answers: [
            {
                id: '51',
                value: 'Правда',
                correct: true,
            },
            {
                id: '52',
                value: ' Ложь',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 15: Кто считается самым юным обладателем Оскара?',
        answers: [
            {
                id: '53',
                value: 'Дженнифер Лоуренс',
                correct: false,
            },
            {
                id: '54',
                value: 'Микки Руни',
                correct: false,
            },

            {
                id: '55',
                value: ' Хейли Джоэл Осмент',
                correct: false,
            },
            {
                id: '56',
                value: 'Татум О Нил',
                correct: true,
            },
            
        ]
    },
    {
        question: 'Вопрос 16: Какой фильм — самый кассовый в истории кино?',
        answers: [
            {
                id: '57',
                value: '«Мстители: Финал»',
                correct: false,
            },
            {
                id: '58',
                value: '«Звездные войны: Пробуждение силы»',
                correct: false,
            },

            {
                id: '59',
                value: '«Аватар»',
                correct: true,
            },
            {
                id: '60',
                value: '«Титаник»',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Правда или ложь: первые премии Американской киноакадемии были вручены в 1925 году?',
        answers: [
            {
                id: '61',
                value: 'Правда',
                correct: false,
            },
            {
                id: '62',
                value: 'Ложь',
                correct: true,
            },
            
        ]
    },
    {
        question: 'Вопрос 18: Какой комик появился в качестве зомби в «Добро пожаловать в Zомбилэнд»?',
        answers: [
            {
                id: '63',
                value: 'Чеви Чейз',
                correct: false,
            },
            {
                id: '64',
                value: 'Дэн Эйкройд',
                correct: false,
            },

            {
                id: '65',
                value: 'Билл Мюррей',
                correct: true,
            },
            {
                id: '66',
                value: ' Стив Мартин',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 19: Во многих мультфильмах имеется пасхалка в виде надписи А113. В жизни это реальный номер, но чего?',
        answers: [
            {
                id: '67',
                value: 'Аудитории института искусств',
                correct: true,
            },
            {
                id: '68',
                value: 'Звезды на Аллее Славы Уолта Диснея',
                correct: false,
            },

            {
                id: '69',
                value: 'Музейного зала с 26 Оскарами Уолта Диснея',
                correct: false,
            },
            {
                id: '70',
                value: 'Здания (адрес) офиса союза аниматоров',
                correct: false,
            },
            
        ]
    },
    {
        question: 'Вопрос 20: Кто сыграл Бэтмена в фильме "Темный Рыцарь"?',
        answers: [
            {
                id: '71',
                value: 'Майкл Китон',
                correct: false,
            },
            {
                id: '72',
                value: 'Бен Аффлек',
                correct: false,
            },

            {
                id: '73',
                value: 'Джордж Клуни',
                correct: false,
            },
            {
                id: '74',
                value: 'Кристиан Бэйл',
                correct:  true,
            },
            
        ]
    },





];

let localresults ={
    
};

const quiz = document.getElementById('quiz');
const questions = document.getElementById('questions');
const results = document.getElementById('results');
const indicator = document.getElementById('indicator');
const btnNext = document.getElementById('btn-next');
const btnRestart = document.getElementById('btn-restart');
const img = document.getElementById('img');
const text = document.getElementById('text');

const renderQuestions = (index) => {
    renderIndicator(index+1);

    questions.dataset.currentStep = index;
    const renderAnswers = () => data[index].answers
    .map((answer) => `
        <li>
            <label>
                <input class="answer-input" type ="radio" name = ${index} value = ${answer.id}>
                ${answer.value}
            </label>
        </li>
    `)
    .join('');

    questions.innerHTML = `
        <div class="quiz-questions-item">
            <div class="quiz-questions-item_question">${data[index].question}</div>
            <ul class="quiz-questions-item_answer">${renderAnswers()}</ul>
        </div>
    `;

};

const renderResults = () => {
    let content = '';

    const getClassname =(answer, questionIndex) => {
        let classname='';

        if (!answer.correct && answer.id === localresults[questionIndex]) {
            classname = 'answer--invalid';
        } else if (answer.correct) {
            classname = 'answer--valid';
        }

        return classname;

    };

    const getAnswers = (questionIndex) =>  data[questionIndex].answers
    .map((answer) => `<li class=${getClassname(answer, questionIndex)}>${answer.value}</li>`)
    .join('');
    

    data.forEach((question, index) =>{
        content += `
            <div class="quiz-results-item">
                <div class="quiz-results-item_question">${question.question}</div>
                <ul class="quiz-results-item_answer">${getAnswers(index)} </ul>
            </div>
        `;
    });

    results.innerHTML = content;
      
};

const renderIndicator = (currentStep) => {
    indicator.innerHTML = `${currentStep}/${data.length}`;
};

quiz.addEventListener('change', (event) => {
    if(event.target.classList.contains('answer-input')){
        console.log('input');
        localresults[event.target.name] = event.target.value;
        btnNext.disabled = false;
    }
});


quiz.addEventListener('click', (event) => {
    if(event.target.classList.contains('btn-next')) {
        const nextQuestion = Number(questions.dataset.currentStep)+1;
        

        if(data.length === nextQuestion){
            questions.classList.add('questions--hidden');
            results.classList.add('results--visible');
            indicator.classList.add('indicator--hidden');
            btnNext.classList.add('btn-next--hidden');
            btnRestart.classList.add('btn-restart--visible');

            renderResults();
        } else {
            renderQuestions(nextQuestion);
            img.classList.add('img--hidden');
            text.classList.add('text--hidden');
        }

        btnNext.disabled = true;
    }
    
    if(event.target.classList.contains('btn-restart')){
        localresults ={};
        results.innerHTML = '';
        questions.classList.remove('questions--hidden');
        results.classList.remove('results--visible');
        indicator.classList.remove('indicator--hidden');
        btnNext.classList.remove('btn-next--hidden');
        btnRestart.classList.remove('btn-restart--visible');
        img.classList.remove('img--hidden');
        text.classList.remove('text--hidden');
        renderQuestions(0);
    
    }
});




renderQuestions(0);
